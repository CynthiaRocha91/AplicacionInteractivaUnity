using UnityEngine;

public class OpenURL : MonoBehaviour
{
    [Header("Paste the full URL here (including https://)")]
    public string url = "https://example.com";

    public void Open()
    {
        if (string.IsNullOrEmpty(url)) return;
        Application.OpenURL(url);
    }
}
